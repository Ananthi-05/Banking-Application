package com.banking.utils;

public interface Credentials {
	//String url="jdbc:mysql://localhost:3307/serv_project";
	String url = "jdbc:mysql://localhost:3307/serv_project?useSSL=false&allowPublicKeyRetrieval=true";

	String username="root";
	String pwd="root";
}

